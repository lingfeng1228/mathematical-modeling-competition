clc
clear
close all
fName = ["kfenghua.xlsx","kweifenghua.xlsx","pdweifenghua.xlsx","pdfenghua.xlsx"];
shuzhi = zeros(4,16);
for i=1:4
    A = xlsread(fName(i));
    [n,m] = size(A);
    for j = 1:m
       temp = sort(A(:,j));
       ave = 0;
       sum = 0;
       for j=1:n
           alpha = normpdf((j/n-0.5)*3);
           ave = ave + temp(j)*alpha;
           sum = sum + alpha;
       end
       ave = ave / sum;
       shuzhi(i,j)=ave;
    end
    
end
shuzhi