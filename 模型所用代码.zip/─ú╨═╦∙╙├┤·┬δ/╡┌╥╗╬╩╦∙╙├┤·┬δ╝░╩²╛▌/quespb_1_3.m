clear                   
clc                    
data = xlsread('铅钡玻璃化学成分含量.xlsx');
S = size(data, 1);
j = [data(:, 1: end - 1), ones(S, 1)];
k =  data(:, end);
moxing = regress(k, j);
nihe = j * moxing;
nihe(nihe >= 0.5) = 1;
nihe(nihe <  0.5) = 0;
err = sum((nihe == k)) / S * 100 ;
figure
cm = confusionchart(k, nihe);
cm.Title = 'Confusion Matrix for Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
disp(moxing')
figure
plot(1: S, k, 'r+-', 1: S, nihe, 'b-o', 'LineWidth', 1)
legend('真实值', '预测值')
xlabel('样本值')
ylabel('预测结果')
string = {'铅钡玻璃化学成分成分预测结果对比'; ['准确率=' num2str(err) '%']};
title(string)
xlim([1, S])
grid
