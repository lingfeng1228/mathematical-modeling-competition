data1 = [1,2,5,10,20,30];
data2 = [2,1,1,2,1,1,2,2];
for i=1:length(data1)
    per = data1(i);
    d = "rand" + per;
    mkdir(d);
    data = "待预测数据.xlsx";
    copyfile(data,d);
    data = d + "/" + data;
    B = xlsread(data);
    [n,m] = size(B);
    R = rand(n,m-2).*0.01*per + 1-per*0.005;
    B(:,1:m-2) = B(:,1:m-2).*R;
    xlswrite(data,B,"C2:R" + (n+1));
end
pause(1);
err = 0;
tt1 = 0;
for i=1:length(data1)
    per = data1(i);
    d = "rand" + per;
    data = d + "/待预测数据.xlsx";
    
    Result = Test(data);
    for j=1:length(Result)
       if Result(j)~=data2(j)
           err = err + 1;
       end
       tt1 = tt1 +1;
    end
    CorP(i) = (1 - err/tt1)*100;
end
CorP
function Result = Test(fileName)
M = xlsread("所有中心点.xlsx");
N = [[4,5],[2,3,10],[7,8,9,13],[11]];
S = zeros(4,2,13);
S(1,:,:) = M(1:1:2,2:1:14);
S(2,:,:) = M(3:1:4,2:1:14);
S(3,:,:) = M(5:1:6,2:1:14);
S(4,:,:) = M(10:1:11,2:1:14);
error = 0;
total = 0;
D = xlsread(fileName);
[n,m] = size(D);
for i =1:n
    flag = D(i,16);
    v = N(flag);
    x1 = GetNorm(v,D(i,2:14),S(flag,1,:));
    x2 = GetNorm(v,D(i,2:14),S(flag,2,:));
    if x1>x2
        Result(i) = 1;
    else
        Result(i) = 2;
    end
end
end
function V1 = GetNorm(s,x,y)
V1 = 0;
for i=1:length(s)
        V1 = V1 + (x(1,s(i))-y(1,1,s(i)))*(x(1,s(i))-y(1,1,s(i)));
end
end
