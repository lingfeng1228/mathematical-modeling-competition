clc;clear;
d=xlsread('铅钡玻璃未风化化学成分数据');
i = @(X,K)(kmeans(X,K));
e = evalclusters(d,i,"CalinskiHarabasz","KList",2:6);
clear i
S = e.OptimalK;
zhibaio = e.OptimalY;
figure
bar(e.InspectedK,e.CriterionValues);
xticks(e.InspectedK);
xlabel("铅钡玻璃未风化最优分类数目");
ylabel("评价指标CH值");
legend("最优分类数目是" + num2str(S));
title("最优分类数求解");
disp("最优分类数目是" + num2str(S));
zhixin = grpstats(d,zhibaio,"mean");
figure
[~,score] = pca(d);
jvleifangfa = grpstats(score,zhibaio,"mean");
h = gscatter(score(:,1),score(:,2),zhibaio,colormap("lines"));
for i = 1:numel(h)
    h(i).DisplayName = strcat("类型",h(i).DisplayName);
end
clear h i score
hold on
h = scatter(jvleifangfa(:,1),jvleifangfa(:,2),50,"kx","LineWidth",2);
hold off
h.DisplayName = "聚类方法";
clear h clusterMeans
legend;
title("pac降维主成分分析");
xlabel("第一主成分");
ylabel("第二主成分");
figure
liedata = sort([1,2]);
[~,ax] = gplotmatrix(d(:,liedata),[],zhibaio,colormap("lines"),[],[],[],"grpbars");
title("分类中数据列的比较");
clear K
jvleifangfa = grpstats(d,zhibaio,"mean");
hold(ax,"on");
for i = 1 : size(liedata,2)
  for j = 1 : size(liedata,2)
      if i ~= j  
          scatter(ax(j,i),jvleifangfa(:,liedata(i)),jvleifangfa(:,liedata(j)), ...
            50,"kx","LineWidth",1.5,"DisplayName","聚类方法");
          xlabel(ax(size(liedata,2),i),("列" + liedata(i)));
          ylabel(ax(i,1),("列" + liedata(i)));
      end
   end
end
clear ax clusterMeans i j selectedCols
dataCHI=max(e.CriterionValues);
data2 = evalclusters(d,zhibaio,"DaviesBouldin");
dataDBI=data2.CriterionValues;
data3 = evalclusters(d,zhibaio,"silhouette");
dataSC=data3.CriterionValues;
disp(['评价指标'])
disp(['Km++CHI指数：',num2str(dataCHI)])
disp(['Kme++DBI指数：',num2str(dataDBI)])
disp(['Km++轮廓系数：',num2str(dataSC)])