data = ["高钾玻璃风化","高钾玻璃无风化","铅钡玻璃风化","铅钡玻璃无风化"];
v1 = [1,2,5,10,20,30,50,100];
for i=1:length(v1)
    per = v1(i);
    dic = "rand" + per;
    mkdir(dic);
    for j=1:4
        d = data(j) + ".xlsx";
        copyfile(d,dic);
        d = dic + "/" + d;
        D = xlsread(d);
        [n,m] = size(D);
        S = rand(n,m-3).*0.01*per + 1-per*0.005;
        D(:,3:m-1) = D(:,3:m-1).*S;
        D(:,m) = sum(D(:,3:m-1),2);
        xlswrite(d,D,"E2:U" + (n+1));
    end
end