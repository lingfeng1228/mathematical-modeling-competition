clear                   
clc                     
data = xlsread('高钾玻璃化学成分预测.xlsx');
S = size(data, 1);
for i = 0 : 3
    j = [data(:, 1: end - 4), ones(S, 1)];
    k =  data(:, end - i);
    moxing = regress(k, j);
    nihe = j * moxing;
    nihe(nihe < 0) = 0;
    cuowulv = sqrt(sum((nihe - k).^2) ./ S);
    figure
    plot(1: S, k, 'r-+', 1: S, nihe, 'b-o', 'LineWidth', 1)
    legend('真实值', '预测值')
    xlabel('预测样本')
    ylabel('预测结果')
    string = {'预测结果对比'; ['RMSE=' num2str(cuowulv)]};
    title(string)
    xlim([1, S])
    grid
    None_qb = j(13: end, :);
    None_qb(:, 1) = 0;
    cuowulv2(:, i + 1) = None_qb * moxing;
    cuowulv2(cuowulv2 < 0) = 0;

end

xlswrite('高钾玻璃化学成分预测结果.xlsx', cuowulv2)