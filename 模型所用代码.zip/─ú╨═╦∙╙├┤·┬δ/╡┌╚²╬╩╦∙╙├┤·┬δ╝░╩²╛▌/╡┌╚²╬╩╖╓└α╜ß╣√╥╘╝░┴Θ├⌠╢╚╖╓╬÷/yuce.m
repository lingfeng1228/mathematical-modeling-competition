clc
clear
R = Test("待预测数据.xlsx")
function R = Test(fileName)
S = xlsread("所有中心点.xlsx");
W = [[4,5],[2,3,10],[7,8,9,13],[11]];
M = zeros(4,2,13);
M(1,:,:) = S(1:1:2,2:1:14);
M(2,:,:) = S(3:1:4,2:1:14);
M(3,:,:) = S(5:1:6,2:1:14);
M(4,:,:) = S(10:1:11,2:1:14);
error = 0;
total = 0;
D = xlsread(fileName);
[n,m] = size(D);
for i =1:n
    flag = D(i,16);
    a = W(flag);
    x1 = GetNorm(a,D(i,2:14),M(flag,1,:));
    x2 = GetNorm(a,D(i,2:14),M(flag,2,:));
    %判断
    if x1>x2
        R(i) = 1;
    else
        R(i) = 2;
    end
end

end
function V1 = GetNorm(p,a,b)
V1 = 0;
for i=1:length(p)
        V1 = V1 + (a(1,p(i))-b(1,1,p(i)))*(a(1,p(i))-b(1,1,p(i)));
end
end
