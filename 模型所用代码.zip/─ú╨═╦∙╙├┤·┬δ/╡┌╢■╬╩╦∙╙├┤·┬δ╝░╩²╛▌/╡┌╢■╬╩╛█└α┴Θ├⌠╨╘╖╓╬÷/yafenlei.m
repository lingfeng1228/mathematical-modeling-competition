clc
clear
close all
data = ["高钾类玻璃风化.xlsx","高钾类玻璃无风化.xlsx","铅钡类玻璃风化.xlsx","铅钡类玻璃无风化.xlsx"];
DICN = [1,2,5,10,20,30];
M = xlsread("所有中心点.xlsx");
S = [[4,5],[2,3,10],[7,8,9,13],[11]];
F = zeros(4,2,13);
F(1,:,:) = M(1:1:2,2:1:14);
F(2,:,:) = M(3:1:4,2:1:14);
F(3,:,:) = M(5:1:6,2:1:14);
F(4,:,:) = M(10:1:11,2:1:14);
err = 0;
ttl = 0;
for f=1:4
    s = S(f);
    D = xlsread(data(f));
    [n,m] = size(D);
    data1 = D(:,4:m-1);
    for i=1:n      
       x1 = GetNorm(s,data1(i,:),F(f,1,:));
       x2 = GetNorm(s,data1(i,:),F(f,2,:));
       if x1>x2
           R(f,i) = 1;
       else
           R(f,i) = 2;
       end
    end
    for k = 1:length(DICN)
        D =  xlsread( "扰动后数据\rand" + DICN(k) + "\" + data(f));
        [n,m] = size(D);
        data1 = D(:,4:m-1);
        for ii=1:n
            x1 = GetNorm(s,data1(ii,:),F(f,1,:));
            x2 = GetNorm(s,data1(ii,:),F(f,2,:));
            if x1>x2
                res = 1;
            else
                res = 2;
            end
            if res ~= R(f,ii)
                err = err + 1;
            end
            ttl = ttl + 1;
        end
        
        er(f,k) =(1- err/ttl)*100;
        ttl = 0;
        err = 0;
    end
end
er

function v1 = GetNorm(s,m,f)
    v1 = 0;
    for i=1:length(s)
        v1 = v1 + (m(1,s(i))-f(1,1,s(i)))*(m(1,s(i))-f(1,1,s(i)));
    end
end
